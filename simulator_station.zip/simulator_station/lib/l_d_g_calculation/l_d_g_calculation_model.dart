import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'l_d_g_calculation_widget.dart' show LDGCalculationWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LDGCalculationModel extends FlutterFlowModel<LDGCalculationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
