import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 't_o_calculation_widget.dart' show TOCalculationWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TOCalculationModel extends FlutterFlowModel<TOCalculationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
